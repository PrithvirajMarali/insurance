"""
check_coverage.py
─────────────────
Skill script for: claim-analysis

Determines whether a given claim type is covered, not covered, or possibly
covered based on the policy text provided.

Input (via stdin): A JSON string with two keys:
    {
        "claim_type": "hospitalisation",
        "policy_text": "<full extracted policy text>"
    }

Output: A structured plain-text coverage analysis with verdict, reason,
        relevant clause, and any conditions/exclusions.
"""

import json
import sys


def analyse_coverage(claim_type: str, policy_text: str) -> str:
    """
    Scan the policy text for coverage clauses, exclusions, and waiting periods
    relevant to the given claim type, then return a structured verdict.
    """
    claim_lower = claim_type.lower().strip()
    policy_lower = policy_text.lower()

    # ── Keyword maps for common claim types ──────────────────────────────────
    COVERAGE_KEYWORDS = {
        "hospitalisation": ["hospitalisation", "hospitalization", "inpatient", "hospital admission", "room rent"],
        "accident": ["accident", "accidental", "personal accident", "bodily injury"],
        "theft": ["theft", "burglary", "stolen", "robbery"],
        "maternity": ["maternity", "pregnancy", "childbirth", "delivery", "prenatal"],
        "critical illness": ["critical illness", "cancer", "heart attack", "stroke", "major illness"],
        "death": ["death benefit", "life cover", "nominee", "sum assured on death"],
        "outpatient": ["outpatient", "opd", "day care", "consultation"],
        "dental": ["dental", "teeth", "oral"],
        "vision": ["vision", "spectacles", "glasses", "eye care", "optical"],
    }

    EXCLUSION_KEYWORDS = [
        "exclusion", "not covered", "excluded", "not admissible",
        "not payable", "waiting period", "pre-existing", "pre existing",
    ]

    # ── Match the claim type to known keyword groups ─────────────────────────
    matched_keywords = []
    for category, keywords in COVERAGE_KEYWORDS.items():
        if any(kw in claim_lower for kw in [category]) or any(kw in claim_lower for kw in keywords):
            matched_keywords = keywords
            break

    # If no category matched, use the raw claim type as keywords
    if not matched_keywords:
        matched_keywords = [claim_lower]

    # ── Search for coverage mentions ─────────────────────────────────────────
    covered_lines = []
    exclusion_lines = []

    for line in policy_text.splitlines():
        line_lower = line.lower()
        if any(kw in line_lower for kw in matched_keywords):
            if any(ex in line_lower for ex in EXCLUSION_KEYWORDS):
                exclusion_lines.append(line.strip())
            else:
                covered_lines.append(line.strip())

    # ── Build verdict ────────────────────────────────────────────────────────
    if covered_lines and not exclusion_lines:
        verdict = "✅ COVERED"
        reason = f"The policy contains explicit coverage provisions for '{claim_type}'."
    elif covered_lines and exclusion_lines:
        verdict = "⚠️  PARTIALLY COVERED / CONDITIONS APPLY"
        reason = f"The policy covers '{claim_type}' but with exclusions or conditions."
    elif exclusion_lines:
        verdict = "❌ NOT COVERED"
        reason = f"The policy explicitly excludes or restricts '{claim_type}'."
    else:
        verdict = "❓ UNCLEAR — MANUAL REVIEW NEEDED"
        reason = (
            f"No direct mention of '{claim_type}' found in the policy text. "
            "The agent will answer based on general policy context."
        )

    # ── Format output ─────────────────────────────────────────────────────────
    lines = [
        f"Claim Type Checked: {claim_type}",
        f"Status: {verdict}",
        f"Reason: {reason}",
        "",
    ]

    if covered_lines:
        lines.append("Relevant Coverage Clauses:")
        for cl in covered_lines[:5]:  # limit to 5 to keep output concise
            lines.append(f"  - {cl}")
        lines.append("")

    if exclusion_lines:
        lines.append("Exclusions / Conditions Found:")
        for ex in exclusion_lines[:5]:
            lines.append(f"  - {ex}")
        lines.append("")

    lines.append(
        "Note: This is a keyword-based scan. The agent will use this as a "
        "starting point and apply full reasoning over the policy text."
    )

    return "\n".join(lines)


def main() -> None:
    raw = sys.stdin.read().strip()

    if not raw:
        print("ERROR: No input provided. Send JSON with 'claim_type' and 'policy_text'.")
        sys.exit(1)

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        # Fallback: treat raw input as just a claim type with no policy text
        data = {"claim_type": raw, "policy_text": ""}

    claim_type = data.get("claim_type", "").strip()
    policy_text = data.get("policy_text", "").strip()

    if not claim_type:
        print("ERROR: 'claim_type' is required in the input JSON.")
        sys.exit(1)

    result = analyse_coverage(claim_type, policy_text)
    print(result)


if __name__ == "__main__":
    main()
