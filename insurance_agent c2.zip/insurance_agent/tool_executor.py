"""
tool_executor.py
----------------
Finds and runs skill scripts on behalf of Claude.

Usage (from claude_client.py):
    from tool_executor import run_script
    result = run_script("check_coverage.py", json_input_string, config.SKILLS_DIR)
"""

import subprocess
import sys
from pathlib import Path


TIMEOUT_SECONDS = 10
MAX_OUTPUT_CHARS = 2000


def _find_script(script_name: str, skills_dir: str) -> Path | None:
    """
    Search all skill subdirectories for a script with the given filename.
    Returns the absolute Path if found, else None.
    """
    skills_path = Path(skills_dir)
    for skill_dir in skills_path.iterdir():
        if skill_dir.is_dir():
            candidate = skill_dir / "scripts" / script_name
            if candidate.exists():
                return candidate
    return None


def run_script(script_name: str, input_data: str, skills_dir: str) -> str:
    """
    Locate and execute a skill script, feeding input_data via stdin.

    Args:
        script_name:  Filename of the script (e.g. 'check_coverage.py').
        input_data:   String passed to the script via stdin.
        skills_dir:   Absolute path to the skills/ directory.

    Returns:
        A string containing stdout output (truncated if too long),
        or an error message if execution fails.
    """
    script_path = _find_script(script_name, skills_dir)

    if script_path is None:
        return (
            f"ERROR: Script '{script_name}' not found in any skill's scripts/ folder.\n"
            f"Available scripts:\n{_list_all_scripts(skills_dir)}"
        )

    try:
        result = subprocess.run(
            [sys.executable, str(script_path)],
            input=input_data,
            capture_output=True,
            text=True,
            timeout=TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        return f"ERROR: Script '{script_name}' timed out after {TIMEOUT_SECONDS}s."
    except Exception as exc:
        return f"ERROR: Could not run script '{script_name}': {exc}"

    output = result.stdout
    if result.stderr:
        output += f"\n[stderr]: {result.stderr[:500]}"
    if result.returncode != 0:
        output += f"\n[exit code {result.returncode}]"

    # Truncate to avoid overloading the context window
    if len(output) > MAX_OUTPUT_CHARS:
        output = output[:MAX_OUTPUT_CHARS] + "\n... [output truncated]"

    return output.strip() or "(no output)"


def _list_all_scripts(skills_dir: str) -> str:
    """Return a newline-separated list of all available script paths."""
    skills_path = Path(skills_dir)
    scripts = []
    for skill_dir in sorted(skills_path.iterdir()):
        if skill_dir.is_dir():
            scripts_dir = skill_dir / "scripts"
            if scripts_dir.is_dir():
                for s in sorted(scripts_dir.glob("*.py")):
                    scripts.append(f"  {skill_dir.name}/scripts/{s.name}")
    return "\n".join(scripts) if scripts else "  (none found)"
