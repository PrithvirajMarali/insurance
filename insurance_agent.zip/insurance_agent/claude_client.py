"""
claude_client.py
────────────────
Thin wrapper around the Anthropic Messages API.
Exposes a single `ask()` method that sends a prompt and returns Claude's reply.
"""

from anthropic import Anthropic

import config


class ClaudeClient:
    """
    Sends a prompt to Claude and returns the text response.

    Args:
        api_key:    Anthropic API key (defaults to config.API_KEY).
        model:      Model identifier (defaults to config.MODEL_NAME).
        max_tokens: Maximum tokens in the response (defaults to config.MAX_TOKENS).
    """

    def __init__(
        self,
        api_key: str = config.API_KEY,
        model: str = config.MODEL_NAME,
        max_tokens: int = config.MAX_TOKENS,
    ) -> None:
        if api_key == "PASTE_YOUR_API_KEY_HERE":
            raise ValueError(
                "Please set your Anthropic API key in config.py "
                "(API_KEY = 'sk-ant-...')"
            )
        self._client = Anthropic(api_key=api_key)
        self._model = model
        self._max_tokens = max_tokens

    def ask(self, prompt: str) -> str:
        """
        Send a prompt to Claude and return the assistant's reply.

        Args:
            prompt: The full prompt string assembled by the caller.

        Returns:
            The text response from Claude.
        """
        response = self._client.messages.create(
            model=self._model,
            max_tokens=self._max_tokens,
            messages=[
                {"role": "user", "content": prompt},
            ],
        )
        return response.content[0].text.strip()
