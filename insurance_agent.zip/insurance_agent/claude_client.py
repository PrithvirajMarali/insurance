"""
claude_client.py
────────────────
Thin wrapper around the company's internal LLM API.
Exposes a single `ask()` method that sends a prompt and returns the reply.
"""

import requests

import config

_API_URL = "https://models.streamline.xceedance.com/v1/chat/completions"


class ClaudeClient:
    """
    Sends a prompt to the internal LLM API and returns the text response.

    Args:
        api_key:    API key (defaults to config.API_KEY).
        model:      Model identifier (defaults to config.MODEL_NAME).
        max_tokens: Maximum tokens in the response (defaults to config.MAX_TOKENS).
    """

    def __init__(
        self,
        api_key: str = config.API_KEY,
        model: str = config.MODEL_NAME,
        max_tokens: int = config.MAX_TOKENS,
    ) -> None:
        if api_key == "PASTE_YOUR_API_KEY_HERE":
            raise ValueError(
                "Please set your API key in config.py (API_KEY = '...')"
            )
        self._api_key = api_key
        self._model = model
        self._max_tokens = max_tokens

    def ask(self, prompt: str) -> str:
        """
        Send a prompt to the internal API and return the assistant's reply.

        Args:
            prompt: The full prompt string assembled by the caller.

        Returns:
            The text response from the model.
        """
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self._model,
            "messages": [
                {"role": "user", "content": prompt},
            ],
            "max_tokens": self._max_tokens,
        }
        response = requests.post(_API_URL, headers=headers, json=payload)
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"].strip()
