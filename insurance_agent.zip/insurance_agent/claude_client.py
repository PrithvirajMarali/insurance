"""
claude_client.py
────────────────
Agentic wrapper around the company's internal LLM API.

Supports the code execution tool — Claude can call `run_script` during its
response. The client runs an agentic loop: send → receive tool call → execute
script → return result to model → repeat until a final text answer is produced.
"""

import json
import requests

import config
from tool_executor import run_script

_API_URL = "https://models.streamline.xceedance.com/v1/chat/completions"

# ── Tool definition sent to the model ─────────────────────────────────────────
_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "run_script",
            "description": (
                "Execute a skill script to perform a precise calculation or lookup. "
                "Use this when the user's question can be answered more accurately "
                "by running one of the available scripts (e.g. check_coverage.py, "
                "classify_risk.py, simplify_clause.py). "
                "Pass structured data as a JSON string via input_data."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "script_name": {
                        "type": "string",
                        "description": (
                            "Filename of the script to run, e.g. 'check_coverage.py'. "
                            "Must exist in one of the skill scripts/ folders."
                        ),
                    },
                    "input_data": {
                        "type": "string",
                        "description": (
                            "Data to pass to the script via stdin. "
                            "For most scripts this is a JSON string. "
                            "For simplify_clause.py, pass the raw clause text."
                        ),
                    },
                },
                "required": ["script_name", "input_data"],
            },
        },
    }
]


class ClaudeClient:
    """
    Sends a prompt to the internal LLM API and returns the assistant's reply.
    Supports an agentic tool-use loop: if the model calls `run_script`,
    the script is executed locally and the result is fed back to the model.

    Args:
        api_key:    API key (defaults to config.API_KEY).
        model:      Model identifier (defaults to config.MODEL_NAME).
        max_tokens: Maximum tokens per response (defaults to config.MAX_TOKENS).
    """

    def __init__(
        self,
        api_key: str = config.API_KEY,
        model: str = config.MODEL_NAME,
        max_tokens: int = config.MAX_TOKENS,
    ) -> None:
        if api_key == "PASTE_YOUR_API_KEY_HERE":
            raise ValueError(
                "Please set your API key in config.py (API_KEY = '...')"
            )
        self._api_key = api_key
        self._model = model
        self._max_tokens = max_tokens
        self._headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

    # ─────────────────────────────────────────────────────────────────────────
    #  Public API
    # ─────────────────────────────────────────────────────────────────────────

    def ask(self, prompt: str) -> str:
        """
        Send a prompt and return the final text answer, running the agentic
        tool-use loop if the model calls `run_script`.

        Args:
            prompt: The full prompt string assembled by the caller.

        Returns:
            The model's final text response.
        """
        messages = [{"role": "user", "content": prompt}]
        return self._agentic_loop(messages)

    # ─────────────────────────────────────────────────────────────────────────
    #  Internal loop
    # ─────────────────────────────────────────────────────────────────────────

    def _agentic_loop(self, messages: list[dict]) -> str:
        """
        Run the model in a loop:
          1. Send messages + tools
          2. If model returns a tool_call → execute → append result → repeat
          3. If model returns text → return it
        """
        MAX_ITERATIONS = 5  # safety cap against infinite loops

        for iteration in range(MAX_ITERATIONS):
            response_msg = self._call_api(messages)
            tool_calls = response_msg.get("tool_calls")

            if not tool_calls:
                # ── Final text answer ─────────────────────────────────────
                return (response_msg.get("content") or "").strip()

            # ── Execute each tool call the model requested ────────────────
            messages.append({"role": "assistant", **response_msg})

            for tc in tool_calls:
                tool_result = self._execute_tool_call(tc)
                messages.append(tool_result)

        # Fallback if loop exhausted (shouldn't normally happen)
        return "Agent loop limit reached. Please rephrase your question."

    def _call_api(self, messages: list[dict]) -> dict:
        """
        Make one API call and return the assistant message dict
        (which may or may not contain tool_calls).
        """
        payload = {
            "model": self._model,
            "messages": messages,
            "max_tokens": self._max_tokens,
            "tools": _TOOLS,
        }
        response = requests.post(_API_URL, headers=self._headers, json=payload)
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]

    def _execute_tool_call(self, tool_call: dict) -> dict:
        """
        Execute a single tool_call returned by the model and return
        the tool-result message to append to the conversation.
        """
        function = tool_call["function"]
        tool_call_id = tool_call["id"]
        fn_name = function["name"]

        try:
            args = json.loads(function["arguments"])
        except (json.JSONDecodeError, KeyError):
            args = {}

        if fn_name == "run_script":
            script_name = args.get("script_name", "")
            input_data  = args.get("input_data", "")
            print(f"\n  [Tool called: {script_name}]")
            result = run_script(script_name, input_data, config.SKILLS_DIR)
        else:
            result = f"Unknown tool: {fn_name}"

        return {
            "role": "tool",
            "tool_call_id": tool_call_id,
            "name": fn_name,
            "content": result,
        }
