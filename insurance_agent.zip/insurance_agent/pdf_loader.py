"""
pdf_loader.py
─────────────
Loads a PDF file and extracts its full text content using pypdf.
"""

from pathlib import Path

import pypdf


def load_pdf(pdf_path: str) -> str:
    """
    Extract and return all text from a PDF file.

    Args:
        pdf_path: Absolute or relative path to the PDF file.

    Returns:
        A single string containing the text of all pages joined together.

    Raises:
        FileNotFoundError: If the PDF does not exist at the given path.
        ValueError: If the PDF contains no extractable text.
    """
    path = Path(pdf_path)

    if not path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    pages = []
    with open(path, "rb") as fh:
        reader = pypdf.PdfReader(fh)
        for page in reader.pages:
            text = page.extract_text() or ""
            if text.strip():
                pages.append(text)

    if not pages:
        raise ValueError(
            f"No extractable text found in '{pdf_path}'. "
            "The PDF might be scanned or image-based."
        )

    return "\n\n".join(pages)
