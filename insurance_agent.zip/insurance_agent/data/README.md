# data/

Place your insurance policy PDF files in this directory.

## Quick Start

```bash
# Copy your PDF here
cp ~/Downloads/my_health_policy.pdf data/

# Then run the agent (it auto-detects the first PDF in data/)
python main.py
```

## Passing a PDF directly

```bash
python main.py path/to/any_policy.pdf
```

## Notes

- The agent supports any text-based PDF (not scanned images).
- For scanned PDFs, use an OCR tool (e.g., Adobe Acrobat, Tesseract) to
  convert them to text-based PDFs first.
