"""
main.py
───────
Entry point for the Insurance Policy AI Agent.

Run:
    python main.py [path/to/policy.pdf]

If no PDF path is given, the agent looks for any PDF inside the data/ directory.
"""

import os
import sys
import textwrap
from pathlib import Path

import config
from claude_client import ClaudeClient
from tool_executor import run_script


# ─────────────────────────────────────────────────────────────────────────────
#  Constants
# ─────────────────────────────────────────────────────────────────────────────

DIVIDER = "-" * 40


# ─────────────────────────────────────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────────────────────────────────────

def banner() -> None:
    """Print the application header."""
    print(f"\n{DIVIDER}")
    print("  Insurance Policy Agent")
    print(f"{DIVIDER}\n")


def find_default_pdf() -> str | None:
    """Return the first PDF found in the data/ directory, or None."""
    data_dir = Path(config.DATA_DIR)
    if data_dir.is_dir():
        for pdf in data_dir.glob("*.pdf"):
            return str(pdf)
    return None


def _strip_frontmatter(text: str) -> str:
    """
    Remove YAML frontmatter (--- ... ---) from the top of a markdown file.
    The frontmatter is metadata used for skill routing, not agent instructions.
    """
    if text.startswith("---"):
        end = text.find("---", 3)
        if end != -1:
            return text[end + 3:].lstrip()
    return text


def load_all_skills() -> str:
    """
    Load skills following the Anthropic skill format:
      skills/<skill-name>/SKILL.md

    Falls back to top-level *.md files for backwards compatibility.
    YAML frontmatter is stripped before the content is injected into the prompt.

    Returns:
        A formatted string with all skill instructions, or an empty
        string if no skill files are found.
    """
    skills_dir = Path(config.SKILLS_DIR)
    if not skills_dir.is_dir():
        return ""

    skill_blocks = []

    # ── Primary: Anthropic-format subdirectory skills ─────────────────────
    for skill_dir in sorted(skills_dir.iterdir()):
        if skill_dir.is_dir():
            skill_file = skill_dir / "SKILL.md"
            if skill_file.exists():
                raw = skill_file.read_text(encoding="utf-8").strip()
                content = _strip_frontmatter(raw)
                if content:
                    skill_blocks.append(content)

    # ── Fallback: top-level *.md files (legacy) ───────────────────────────
    if not skill_blocks:
        for skill_file in sorted(skills_dir.glob("*.md")):
            content = skill_file.read_text(encoding="utf-8").strip()
            if content:
                skill_blocks.append(content)

    return "\n\n".join(skill_blocks)


def build_prompt(skills: str, policy_text: str, question: str) -> str:
    """
    Combine skill instructions, the full policy text, and the user's
    question into one prompt for Claude.

    Args:
        skills:      Combined skill instructions from all .md files.
        policy_text: Full extracted text from the insurance policy PDF.
        question:    The user's question.

    Returns:
        A formatted prompt string ready to send to Claude.
    """
    prompt = f"""\
{skills}

{'═' * 50}
INSURANCE POLICY DOCUMENT
{'═' * 50}
{policy_text}

{'═' * 50}
USER QUESTION
{'═' * 50}
{question}

Answer the question using only the information in the policy document above.
If the answer is not found in the document, say so clearly.
"""
    return prompt.strip()


def print_answer(answer: str) -> None:
    """Print Claude's answer wrapped at 70 characters."""
    print(f"\nAnswer:")
    print(DIVIDER)
    for line in answer.splitlines():
        # Wrap long lines; preserve blank lines as-is
        if line.strip():
            print(textwrap.fill(line, width=70))
        else:
            print()
    print(f"{DIVIDER}\n")


# ─────────────────────────────────────────────────────────────────────────────
#  Main
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    banner()

    # ── 1. Resolve PDF path ───────────────────────────────────────────────
    pdf_path = sys.argv[1] if len(sys.argv) > 1 else find_default_pdf()

    if not pdf_path:
        print("ERROR: No PDF file found.")
        print("Usage:  python main.py <path/to/policy.pdf>")
        print("   or:  place a PDF in the data/ directory and run without arguments.\n")
        sys.exit(1)

    print(f"Loaded policy: {Path(pdf_path).name}")

    # ── 2. Extract text from the PDF via the pdf-reader skill ──────────────
    print("Reading policy PDF...")
    policy_text = run_script("read_pdf.py", pdf_path, config.SKILLS_DIR)
    if policy_text.startswith("ERROR:"):
        print(f"\n{policy_text}\n")
        sys.exit(1)

    # ── 3. Load all skill instructions ───────────────────────────────────
    skills = load_all_skills()

    # ── 4. Initialise the Claude client ──────────────────────────────────
    try:
        claude = ClaudeClient()
    except ValueError as exc:
        print(f"\nCONFIGURATION ERROR: {exc}\n")
        sys.exit(1)

    # ── 5. Interactive Q&A loop ───────────────────────────────────────────
    print(f"\nAsk a question (type 'exit' or press Ctrl-C to quit):")

    while True:
        print(DIVIDER)
        try:
            question = input("> ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n\nGoodbye!\n")
            break

        if not question:
            continue
        if question.lower() in ("exit", "quit", "q"):
            print("\nGoodbye!\n")
            break

        # ── Build the prompt ──────────────────────────────────────────────
        prompt = build_prompt(skills, policy_text, question)

        print("\nAgent thinking...\n")

        # ── Call Claude ───────────────────────────────────────────────────
        try:
            answer = claude.ask(prompt)
        except Exception as exc:
            print(f"Claude API error: {exc}\n")
            continue

        print_answer(answer)


if __name__ == "__main__":
    main()
