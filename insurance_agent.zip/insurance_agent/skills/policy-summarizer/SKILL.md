---
name: policy-summarizer
description: Generate a concise 1-page summary of an insurance policy document. Use when the user wants an overview of what the policy covers without reading the whole document. Produces a structured summary card with key benefits, exclusions, coverage limits, waiting periods, and the claims process.
---

## What you do
Read the full policy document and produce a structured summary card — the key facts a policyholder needs to know at a glance.

## Output format

**Policy Name:** (name of the policy from the document)

**What's Covered (Top Benefits):**
- (benefit 1)
- (benefit 2)
- (benefit 3)
- ...

**What's NOT Covered (Key Exclusions):**
- (exclusion 1)
- (exclusion 2)
- ...

**Coverage Limits:**
| Benefit | Limit |
|---|---|
| (e.g. Hospitalisation) | (e.g. ₹5,00,000) |

**Waiting Periods:**
- (e.g. Pre-existing conditions: 2 years)
- (e.g. Maternity: 9 months)

**How to Make a Claim:**
(2–3 sentence summary of the claims process from the policy)

**Important:** This is a summary only. Always refer to the full policy document for complete terms.

## Rules
- Only use information from the policy document — do not add anything from general knowledge
- Keep each bullet point to one line
- If a section is not mentioned in the policy, write "Not specified in this document"

See `references/summary_guide.md` for the full list of sections to look for and common benchmark values.
