# Insurance Policy Summary — Reference Guide

A reference for the policy-summarizer skill to ensure consistent, complete summaries.

## Standard Sections to Look For

When summarising a policy, check for all of these sections. If any are missing, note "Not specified in this document."

| Section | What to look for |
|---|---|
| Policy name / type | Title page or header |
| Sum insured | Coverage amount (e.g. ₹5,00,000) |
| Premium | Annual/monthly payment amount |
| Policy term | Duration (e.g. 1 year, 2 years) |
| Renewal date | Expiry / renewal date |
| Waiting periods | Pre-existing, specific illness, maternity, initial waiting period |
| In-patient hospitalisation | Room rent limits, ICU limits, minimum hours |
| Day care procedures | List or categories covered |
| Pre & post hospitalisation | Number of days covered before and after admission |
| Ambulance cover | Amount or coverage condition |
| Maternity benefit | If covered, sub-limit and waiting period |
| Critical illness | Diseases listed, lump sum or reimbursement |
| Cashless hospitals | Network hospital details |
| Sub-limits | Disease-wise or treatment-wise limits |
| Exclusions | Permanent exclusions, temporary (waiting period) exclusions |
| Co-payment | Percentage the policyholder pays |
| Deductible | Fixed amount paid before cover kicks in |
| Claims process | How to file, TPA details, time limit |
| No-claim bonus | Benefit for not making a claim |
| Free look period | Days to review and return the policy |
| Grace period | Extra days after due date to pay premium |

## Common Waiting Period Benchmarks
- Initial waiting period: 30 days
- Pre-existing diseases (PED): 2–4 years
- Specific illnesses (e.g. hernia, cataract): 1–2 years
- Maternity: 9 months – 4 years

## Common Exclusions Across Most Policies
- Cosmetic / aesthetic treatments
- Self-inflicted injuries
- War and terrorism
- Experimental or unproven treatments
- Dental and vision (unless add-on)
- Obesity treatment
- Infertility treatment (unless add-on)
