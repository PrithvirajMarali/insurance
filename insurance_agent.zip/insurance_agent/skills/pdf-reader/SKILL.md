---
name: pdf-reader
description: Read and extract text content from a PDF file. Use this skill first, before any other skill, when the user wants to analyse an insurance policy PDF that has not yet been loaded. Pass the PDF file path to the read_pdf.py script to get the full text back, then use the text as policy context for answering questions.
---

## What you do
Extract all text from an insurance policy PDF file so it can be used to answer the user's questions.

## When to use this
Use this at the start of a session if a PDF path is given but the policy text is not yet available.

## Available Script

| Script | What it does | Input |
|---|---|---|
| `read_pdf.py` | Reads a PDF from disk and returns its full text content | The file path as a plain string (e.g. `data/policy.pdf`) |

**How to call it:**
```json
{ "script_name": "read_pdf.py", "input_data": "data/my_policy.pdf" }
```

The script returns the full text of all pages joined together. Use this text as the policy context when answering the user's question.

## Rules
- Only read files the user has explicitly provided
- If the file is not found or has no readable text, tell the user clearly
