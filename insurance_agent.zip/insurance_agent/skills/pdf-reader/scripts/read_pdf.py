"""
read_pdf.py
───────────
Skill script for: pdf-reader

Reads a PDF file from disk and returns its full text content.
This replaces the need for a separate pdf_loader.py module —
Claude can call this script directly via the run_script tool.

Input (via stdin): The file path to the PDF (plain string).

Output: Full text content of all readable pages, joined together.

Dependencies: pypdf  (pip install pypdf)
"""

import sys
from pathlib import Path

try:
    import pypdf
except ImportError:
    print("ERROR: 'pypdf' is not installed. Run: pip install pypdf")
    sys.exit(1)


def read_pdf(pdf_path: str) -> str:
    """Extract and return all text from a PDF file."""
    path = Path(pdf_path.strip())

    if not path.exists():
        print(f"ERROR: File not found: {pdf_path}")
        sys.exit(1)

    pages = []
    with open(path, "rb") as fh:
        reader = pypdf.PdfReader(fh)
        total = len(reader.pages)
        for i, page in enumerate(reader.pages):
            text = page.extract_text() or ""
            if text.strip():
                pages.append(f"[Page {i + 1}/{total}]\n{text}")

    if not pages:
        print(
            f"ERROR: No readable text found in '{pdf_path}'. "
            "The PDF may be scanned or image-based."
        )
        sys.exit(1)

    return "\n\n".join(pages)


def main() -> None:
    pdf_path = sys.stdin.read().strip()

    if not pdf_path:
        print("ERROR: No file path provided. Send the PDF path via stdin.")
        sys.exit(1)

    text = read_pdf(pdf_path)
    print(f"Successfully extracted text from: {pdf_path}")
    print(f"Total characters: {len(text)}")
    print("─" * 60)
    print(text)


if __name__ == "__main__":
    main()
