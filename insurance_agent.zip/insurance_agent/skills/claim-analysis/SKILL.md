---
name: claim-analysis
description: Check whether an insurance claim is covered, not covered, or partially covered under a policy. Use when the user describes a claim event (accident, hospitalization, theft, etc.) and wants to know if they can claim it. Checks coverage clauses, exclusions, waiting periods, and deductibles.
---

## What you do
Determine if a claim is covered based on the policy document and tell the user why.

## Steps
1. Identify the type of claim (e.g. hospitalization, accident, property damage)
2. Find the relevant policy clause
3. Check for exclusions or waiting periods that may apply
4. Give a clear verdict with the reason

## Output

**Status:** COVERED / NOT COVERED / PARTIALLY COVERED

**Reason:** (plain English explanation of why)

**Policy clause:** (the section this is based on)

**Notes:** (any deductibles, limits, or waiting periods to be aware of)

## Rules
- Only base your answer on the policy document provided
- If you're not sure, say so — don't guess
- Use plain language the user can understand
