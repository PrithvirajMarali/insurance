---
name: document-checklist
description: Generate the exact list of documents needed to submit an insurance claim. Use when the user wants to know what to collect before going to the hospital, filing an accident report, or submitting any claim. Tailors the checklist to the specific claim type mentioned by the user (e.g. hospitalization, accident, theft, death, maternity).
---

## What you do
Based on the claim type the user describes and the policy document, produce a precise checklist of required documents.

## Steps
1. Identify the claim type from the user's question (e.g. hospitalisation, accident, theft, critical illness, death)
2. Find the claims section in the policy document
3. List the required documents for that specific claim type

## Output format

**Claim Type:** (e.g. Hospitalisation Claim)

**Documents Required:**

*Mandatory for all claims:*
- [ ] (document 1)
- [ ] (document 2)

*Specific to this claim type:*
- [ ] (document 3)
- [ ] (document 4)

**Where to submit:** (from the policy — e.g. nearest branch, online portal, TPA)

**Time limit to file:** (deadline mentioned in the policy, if any)

**Tip:** (one practical tip, e.g. "Keep originals and make photocopies of everything before submitting")

## Rules
- Only list documents mentioned in or logically required by the policy
- Use checkboxes (`- [ ]`) so the user can use this as an actual checklist
- If the policy doesn't specify documents for this claim type, say so clearly
