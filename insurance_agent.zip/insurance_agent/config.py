# config.py
# Central configuration for the Insurance Policy AI Agent.
# Fill in your Anthropic API key before running.

import os

# ─────────────────────────────────── API ──────────────────────────────────────
API_KEY: str = "PASTE_YOUR_API_KEY_HERE"

# ──────────────────────────────── Model Settings ──────────────────────────────
MODEL_NAME: str = "claude-sonnet-4-6"
MAX_TOKENS: int = 1024

# ──────────────────────────────── Directory Paths ─────────────────────────────
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
SKILLS_DIR = os.path.join(BASE_DIR, "skills")
DATA_DIR   = os.path.join(BASE_DIR, "data")
